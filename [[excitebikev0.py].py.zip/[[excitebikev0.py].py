import pygame
import random
import sys

# initialize Pygame
pygame.init()

# set up the game window
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Excitebike-style Game")

# define the colors used in the game
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# define the game classes
class Bike(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(WHITE)
        pygame.draw.circle(self.image, RED, (25, 25), 25)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = 0
        
    def update(self):
        self.rect.y += self.speed
        
class Obstacle(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(WHITE)
        pygame.draw.rect(self.image, GREEN, (0, 0, 50, 50))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = -5
        
    def update(self):
        self.rect.x += self.speed
        if self.rect.right < 0:
            self.kill()
            
# create the game objects
all_sprites = pygame.sprite.Group()
obstacles = pygame.sprite.Group()
bike = Bike(screen_width/2, screen_height/2)
all_sprites.add(bike)

# set up the game clock
clock = pygame.time.Clock()

# main game loop
while True:
    # handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                bike.speed = -5
            elif event.key == pygame.K_DOWN:
                bike.speed = 5
                
    # spawn new obstacles
    if random.randint(1, 100) <= 10:
        obstacle = Obstacle(screen_width, random.randint(0, screen_height))
        all_sprites.add(obstacle)
        obstacles.add(obstacle)

    # update the game objects
    all_sprites.update()

    # detect collisions
    if pygame.sprite.spritecollide(bike, obstacles, True):
        print("Game Over!")
        pygame.quit()
        sys.exit()

    # clear the screen
    screen.fill(BLACK)

    # draw the game objects
    all_sprites.draw(screen)

    # update the display
    pygame.display.flip()

    # limit the frame rate
    clock.tick(60)
