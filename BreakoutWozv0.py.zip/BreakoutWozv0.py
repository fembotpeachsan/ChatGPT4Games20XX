import sys
import pygame
from pygame.locals import *

# Constants
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
PADDLE_WIDTH = 60
PADDLE_HEIGHT = 10
BRICK_WIDTH = 60
BRICK_HEIGHT = 20
BALL_SIZE = 10
PADDLE_SPEED = 5
BALL_SPEED = 3

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Wozniak Breakout")

# Create Paddle
paddle = pygame.Rect(SCREEN_WIDTH // 2 - PADDLE_WIDTH // 2, SCREEN_HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT)

# Create Ball
ball = pygame.Rect(SCREEN_WIDTH // 2 - BALL_SIZE // 2, SCREEN_HEIGHT // 2 - BALL_SIZE // 2, BALL_SIZE, BALL_SIZE)
ball_dx, ball_dy = BALL_SPEED, -BALL_SPEED

# Create Bricks
bricks = []
for i in range(10):
    for j in range(4):
        brick = pygame.Rect(i * (BRICK_WIDTH + 5) + 25, j * (BRICK_HEIGHT + 5) + 50, BRICK_WIDTH, BRICK_HEIGHT)
        bricks.append(brick)

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    keys = pygame.key.get_pressed()
    if keys[K_LEFT] and paddle.left > 0:
        paddle.left -= PADDLE_SPEED
    if keys[K_RIGHT] and paddle.right < SCREEN_WIDTH:
        paddle.left += PADDLE_SPEED

    ball.left += ball_dx
    ball.top += ball_dy

    if ball.left <= 0 or ball.right >= SCREEN_WIDTH:
        ball_dx = -ball_dx
    if ball.top <= 0:
        ball_dy = -ball_dy

    if ball.colliderect(paddle):
        ball_dy = -abs(ball_dy)

    for brick in bricks:
        if ball.colliderect(brick):
            bricks.remove(brick)
            ball_dy = -ball_dy
            break

    if ball.top >= SCREEN_HEIGHT:
        ball.left, ball.top = SCREEN_WIDTH // 2 - BALL_SIZE // 2, SCREEN_HEIGHT // 2 - BALL_SIZE // 2
        ball_dy = -abs(ball_dy)

    screen.fill(BLACK)
    pygame.draw.rect(screen, WHITE, paddle)
    pygame.draw.rect(screen, WHITE, ball)

    for brick in bricks:
        pygame.draw.rect(screen, WHITE, brick)

    pygame.display.flip()
    pygame.time.delay(10)
