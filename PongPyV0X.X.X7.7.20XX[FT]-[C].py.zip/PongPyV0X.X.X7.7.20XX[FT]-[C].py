import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
PADDLE_WIDTH, PADDLE_HEIGHT = 10, 60
BALL_SIZE = 10

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set up the display
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Pong')

# Set up the ball and paddles
ball = pygame.Rect(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2, BALL_SIZE, BALL_SIZE)
left_paddle = pygame.Rect(10, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT)
right_paddle = pygame.Rect(SCREEN_WIDTH - 10 - PADDLE_WIDTH, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2, PADDLE_WIDTH, PADDLE_HEIGHT)

# Ball movement
ball_speed_x = 7
ball_speed_y = 7

# Player controls
player_speed = 0
AI_speed = 7

# Scoring
player_score = 0
AI_score = 0
font = pygame.font.Font(None, 32)  # Use the default system font

# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    # Player controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        player_speed = -5
    if keys[pygame.K_DOWN]:
        player_speed = 5
    if not keys[pygame.K_UP] and not keys[pygame.K_DOWN]:
        player_speed = 0
    
    # Move the paddles
    left_paddle.y += player_speed
    right_paddle.y += AI_speed
    
    # Check if the paddles are going out of bounds
    if left_paddle.top < 0:
        left_paddle.top = 0
    if left_paddle.bottom > SCREEN_HEIGHT:
        left_paddle.bottom = SCREEN_HEIGHT
    if right_paddle.top < 0:
        right_paddle.top = 0
    if right_paddle.bottom > SCREEN_HEIGHT:
        right_paddle.bottom = SCREEN_HEIGHT
    
    # Move the ball
    ball.x += ball_speed_x
    ball.y += ball_speed_y
    
    # Ball collision with walls
    if ball.top <= 0 or ball.bottom >= SCREEN_HEIGHT:
        ball_speed_y *= -1
    
    # Ball collision with paddles
    if ball.colliderect(left_paddle) or ball.colliderect(right_paddle):
        ball_speed_x *= -1
    
    # AI movement
    if ball.y > right_paddle.y + right_paddle.height // 2:
        AI_speed = 7
    elif ball.y < right_paddle.y + right_paddle.height // 2:
        AI_speed = -7
    
    # Draw everything
    window.fill(BLACK)
    pygame.draw.rect(window, WHITE, left_paddle)
    pygame.draw.rect(window, WHITE, right_paddle)
    pygame.draw.ellipse(window, WHITE, ball)
    pygame.draw.aaline(window, WHITE, (SCREEN_WIDTH // 2, 0), (SCREEN_WIDTH // 2, SCREEN_HEIGHT))
    
    # Scoring
    if ball.left <= 0:
        AI_score += 1
        ball.x = SCREEN_WIDTH // 2
        ball.y = SCREEN_HEIGHT // 2
    if ball.right >= SCREEN_WIDTH:
        player_score += 1
        ball.x = SCREEN_WIDTH // 2
        ball.y = SCREEN_HEIGHT // 2
    
    # Display scores
    score = font.render(f'Player: {player_score}  AI: {AI_score}', True, WHITE)
    window.blit(score, (SCREEN_WIDTH // 2 - score.get_width() // 2, 10))
    
    pygame.display.flip()
    pygame.time.delay(16)
