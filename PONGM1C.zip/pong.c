#include <SDL2/SDL.h>
#include <stdbool.h>

// Define window dimensions
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

// Define paddle properties
#define PADDLE_WIDTH 15
#define PADDLE_HEIGHT 100
#define PADDLE_SPEED 10

// Define ball properties
#define BALL_SIZE 15
#define BALL_SPEED_X 6
#define BALL_SPEED_Y 6

// SDL variables
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;

// Game objects
SDL_Rect paddleLeft, paddleRight, ball;

// Ball movement speed
int ballSpeedX = BALL_SPEED_X, ballSpeedY = BALL_SPEED_Y;

// Function declarations
void init();
void close_game();
void move_ball();
void move_paddles(SDL_Event* e);

int main(int argc, char* args[]) {
    init();

    bool quit = false;
    SDL_Event e;

    // Game loop
    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            move_paddles(&e);
        }

        // Move the ball
        move_ball();

        // Check for ball collision with walls
        if (ball.y <= 0 || ball.y + BALL_SIZE >= WINDOW_HEIGHT) {
            ballSpeedY = -ballSpeedY;  // Reverse ball direction on wall hit
        }

        // Check if the ball hit the paddles
        if ((ball.x <= paddleLeft.x + PADDLE_WIDTH && ball.y + BALL_SIZE >= paddleLeft.y && ball.y <= paddleLeft.y + PADDLE_HEIGHT) ||
            (ball.x + BALL_SIZE >= paddleRight.x && ball.y + BALL_SIZE >= paddleRight.y && ball.y <= paddleRight.y + PADDLE_HEIGHT)) {
            ballSpeedX = -ballSpeedX;  // Reverse ball direction on paddle hit
        }

        // Ball reset if it goes off-screen
        if (ball.x <= 0 || ball.x + BALL_SIZE >= WINDOW_WIDTH) {
            ball.x = (WINDOW_WIDTH - BALL_SIZE) / 2;
            ball.y = (WINDOW_HEIGHT - BALL_SIZE) / 2;
            ballSpeedX = BALL_SPEED_X;
            ballSpeedY = BALL_SPEED_Y;
        }

        // Render everything
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        // Draw paddles and ball
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderFillRect(renderer, &paddleLeft);
        SDL_RenderFillRect(renderer, &paddleRight);
        SDL_RenderFillRect(renderer, &ball);

        SDL_RenderPresent(renderer);

        SDL_Delay(16);  // Delay to limit frame rate (~60 FPS)
    }

    close_game();
    return 0;
}

void init() {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

    // Create window
    window = SDL_CreateWindow("Pong Game",
                              SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                              WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    if (window == NULL) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

    // Create renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

    // Initialize paddles and ball
    paddleLeft = (SDL_Rect){10, (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2, PADDLE_WIDTH, PADDLE_HEIGHT};
    paddleRight = (SDL_Rect){WINDOW_WIDTH - 10 - PADDLE_WIDTH, (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2, PADDLE_WIDTH, PADDLE_HEIGHT};
    ball = (SDL_Rect){(WINDOW_WIDTH - BALL_SIZE) / 2, (WINDOW_HEIGHT - BALL_SIZE) / 2, BALL_SIZE, BALL_SIZE};
}

void move_ball() {
    ball.x += ballSpeedX;
    ball.y += ballSpeedY;
}

void move_paddles(SDL_Event* e) {
    if (e->type == SDL_KEYDOWN) {
        if (e->key.keysym.sym == SDLK_w && paddleLeft.y > 0) {
            paddleLeft.y -= PADDLE_SPEED;
        }
        if (e->key.keysym.sym == SDLK_s && paddleLeft.y + PADDLE_HEIGHT < WINDOW_HEIGHT) {
            paddleLeft.y += PADDLE_SPEED;
        }
        if (e->key.keysym.sym == SDLK_UP && paddleRight.y > 0) {
            paddleRight.y -= PADDLE_SPEED;
        }
        if (e->key.keysym.sym == SDLK_DOWN && paddleRight.y + PADDLE_HEIGHT < WINDOW_HEIGHT) {
            paddleRight.y += PADDLE_SPEED;
        }
    }
}

void close_game() {
    // Destroy window and renderer
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
