// 🐱‍💻 cat_gpt: Importing standard libraries for input-output and other functionalities
#include <stdio.h>
#include <stdlib.h>

// 🐱‍💻 cat_gpt: Function prototypes for printing the board and checking for a win
void printBoard(char board[3][3]);
int checkWin(char board[3][3]);

// 🐱‍💻 cat_gpt: Main function where the game logic resides
int main() {
    // 🐱‍💻 cat_gpt: Initialize the 3x3 board with empty spaces
    char board[3][3] = { {' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '} };
    int row, col;
    char player = 'X';  // 🐱‍💻 cat_gpt: Start with player X

    // 🐱‍💻 cat_gpt: Game loop
    while (1) {
        // 🐱‍💻 cat_gpt: Display the current board
        printBoard(board);

        // 🐱‍💻 cat_gpt: Prompt the current player for a move
        printf("Player %c, enter your move (row [0-2] col [0-2]): ", player);
        scanf("%d %d", &row, &col);

        // 🐱‍💻 cat_gpt: Validate the move
        if (row < 0 || row > 2 || col < 0 || col > 2) {
            printf("Invalid move. Try again.\n");
            continue;
        }

        // 🐱‍💻 cat_gpt: Check if the cell is already occupied
        if (board[row][col] != ' ') {
            printf("Cell already occupied. Try again.\n");
            continue;
        }

        // 🐱‍💻 cat_gpt: Make the move
        board[row][col] = player;

        // 🐱‍💻 cat_gpt: Check for a win
        if (checkWin(board)) {
            printf("Player %c wins!\n", player);
            break;
        }

        // 🐱‍💻 cat_gpt: Switch to the other player
        player = (player == 'X') ? 'O' : 'X';
    }

    // 🐱‍💻 cat_gpt: Display the final board
    printBoard(board);
    return 0;
}

// 🐱‍💻 cat_gpt: Function to print the Tic-Tac-Toe board
void printBoard(char board[3][3]) {
    printf("Current board:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("%c ", board[i][j]);
        }
        printf("\n");
    }
}

// 🐱‍💻 cat_gpt: Function to check for a win
int checkWin(char board[3][3]) {
    // 🐱‍💻 cat_gpt: Check rows and columns
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != ' ')
            return 1;
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != ' ')
            return 1;
    }
    // 🐱‍💻 cat_gpt: Check diagonals
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != ' ')
        return 1;
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != ' ')
        return 1;

    return 0;
}
