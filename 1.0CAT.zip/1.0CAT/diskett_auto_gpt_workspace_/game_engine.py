from ursina import *
from ursina.physics import *

class GameEngine(Entity):
    def __init__(self):
        super().__init__()
        self.collider = BoxCollider()
        self.model = 'cube'
        self.scale = Vec3(1,1,1)

    def input(self, key):
        pass

    def update(self):
        pass

app = Ursina()
app.run()
app.clear() 
app.close()