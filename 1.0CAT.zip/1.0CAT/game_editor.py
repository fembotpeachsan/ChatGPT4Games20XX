from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()

editor = FirstPersonController()

app.run()