import sys
print(sys.version)
import pip
pip.main(['install', 'ursina'])