import unittest
from game_engine import GameEngine


class TestGameEngine(unittest.TestCase):

    def test_init(self):
        engine = GameEngine()
        self.assertIsNotNone(engine)

if __name__ == '__main__':
    unittest.main()