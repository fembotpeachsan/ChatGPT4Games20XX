import pygame
import sys
import time

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Loading Screen')

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)

# Font setup
font = pygame.font.Font(None, 36)

# Loading text
loading_text = font.render("Loading...", True, WHITE)
loading_rect = loading_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))

# Progress bar setup
progress_bar_width = 400
progress_bar_height = 20
progress_bar_rect = pygame.Rect((WIDTH - progress_bar_width) // 2, HEIGHT // 2, 0, progress_bar_height)

# Progress simulation
progress = 0
progress_step = 1  # How much the progress increases each frame

# Main loop
running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill(BLACK)
    
    # Render loading text
    screen.blit(loading_text, loading_rect)

    # Update progress
    if progress < 100:
        progress += progress_step
        progress_bar_rect.width = (progress / 100) * progress_bar_width
    else:
        # Simulate loading complete, you might want to load your game here
        time.sleep(2)  # Wait for 2 seconds to show full bar
        running = False

    # Draw progress bar
    pygame.draw.rect(screen, GRAY, (progress_bar_rect.x - 2, progress_bar_rect.y - 2, progress_bar_width + 4, progress_bar_height + 4))  # Outline
    pygame.draw.rect(screen, WHITE, progress_bar_rect)  # Fill

    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
sys.exit()