import pygame
import sys

pygame.init()

# Screen setup
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Super Smash Bros. Ultimate Style Game')

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GRAY = (100, 100, 100)

# Font setup
font = pygame.font.Font(None, 40)

# Game States
MENU, SMASH, GAMES_MORE, VAULT, ONLINE, OPTIONS = range(6)

# Initial state
game_state = MENU

def draw_menu(selected):
    options = ["Smash", "Games & More", "Vault", "Online", "Options", "Quit"]
    screen.fill(BLACK)
    for i, option in enumerate(options):
        color = RED if i == selected else WHITE
        text = font.render(option, True, color)
        text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 100 + i * 50))
        screen.blit(text, text_rect)

# Game modes
def smash_mode():
    prompt = font.render("Entering Smash Mode...", True, WHITE)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return MENU
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return MENU
        screen.fill(BLACK)
        screen.blit(prompt, prompt.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
        pygame.display.flip()
        pygame.time.wait(1000)  # Simulate loading or preparation time

def games_and_more():
    prompt = font.render("Games & More selected", True, WHITE)
    return show_prompt(prompt)

def vault():
    prompt = font.render("Vault selected", True, WHITE)
    return show_prompt(prompt)

def online():
    prompt = font.render("Connecting Online...", True, WHITE)
    return show_prompt(prompt)

def options():
    prompt = font.render("Options Menu", True, WHITE)
    return show_prompt(prompt)

def show_prompt(prompt_text):
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return MENU
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return MENU
        screen.fill(BLACK)
        screen.blit(prompt_text, prompt_text.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
        pygame.display.flip()

# Main game loop
running = True
selected = 0
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if game_state == MENU:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % 6
                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % 6
                elif event.key == pygame.K_RETURN:
                    if selected == 0:  # Smash
                        game_state = smash_mode()
                    elif selected == 1:  # Games & More
                        game_state = games_and_more()
                    elif selected == 2:  # Vault
                        game_state = vault()
                    elif selected == 3:  # Online
                        game_state = online()
                    elif selected == 4:  # Options
                        game_state = options()
                    elif selected == 5:  # Quit
                        running = False
            elif event.key == pygame.K_ESCAPE and game_state != MENU:
                game_state = MENU
                selected = 0  # Reset selection when returning to menu

    if game_state == MENU:
        draw_menu(selected)
    pygame.display.flip()

pygame.quit()