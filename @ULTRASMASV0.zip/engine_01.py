import pygame
import sys

pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Super Smash Bros. Ultimate Style Game')

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GRAY = (100, 100, 100)

# Font setup
font = pygame.font.Font(None, 40)

# Loading screen
def loading_screen():
    loading_text = font.render("Loading...", True, WHITE)
    loading_rect = loading_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50))
    progress_bar_width, progress_bar_height = 400, 20
    progress_bar_rect = pygame.Rect((WIDTH - progress_bar_width) // 2, HEIGHT // 2, 0, progress_bar_height)
    progress = 0
    clock = pygame.time.Clock()

    while progress < 100:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)
        screen.blit(loading_text, loading_rect)
        
        progress += 0.5  # Simulated loading speed
        progress_bar_rect.width = (progress / 100) * progress_bar_width
        
        pygame.draw.rect(screen, GRAY, (progress_bar_rect.x - 2, progress_bar_rect.y - 2, progress_bar_width + 4, progress_bar_height + 4))
        pygame.draw.rect(screen, WHITE, progress_bar_rect)
        
        pygame.display.flip()
        clock.tick(60)

    return main_menu()

# Main menu
def main_menu():
    options = ["Smash", "Games & More", "Vault", "Online", "Options", "Quit"]
    selected = 0
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(options)
                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(options)
                elif event.key == pygame.K_RETURN:
                    if selected == len(options) - 1:  # "Quit" option
                        running = False
                    # Here you'd typically start the selected mode or exit

        screen.fill(BLACK)
        
        for i, option in enumerate(options):
            color = WHITE if i != selected else RED
            text = font.render(option, True, color)
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 100 + i * 50))
            screen.blit(text, text_rect)

        pygame.display.flip()

    pygame.quit()

# Start with loading screen
loading_screen()

pygame.quit()