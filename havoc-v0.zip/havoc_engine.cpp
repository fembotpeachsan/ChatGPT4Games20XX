// main.cpp
#include <SDL2/SDL.h>
#include <algorithm> // For std::min
#include <map>
#include <string>

// Constants
const int SPEED = 5;
const int GRAVITY = 1;
const int JUMP_POWER = 15; // Increased jump power for better visibility
const int WIDTH = 800;      // Window width
const int HEIGHT = 600;     // Window height
const double KNOCKBACK_MULTIPLIER = 0.5;

// Color Structure
struct Color {
    Uint8 r, g, b, a;
};

// Player Class
class Player {
public:
    SDL_Rect rect;
    Color color;
    std::map<std::string, SDL_Keycode> controls;
    int x_speed;
    int y_speed;
    int damage;
    bool jumping;
    bool attacking;

    Player(int x, int y, Color c, std::map<std::string, SDL_Keycode> ctrl)
        : color(c), controls(ctrl), x_speed(0), y_speed(0), damage(0), jumping(false), attacking(false) {
        rect.x = x;
        rect.y = y;
        rect.w = 40;
        rect.h = 60;
    }

    void handleEvent(const Uint8* keyState) {
        x_speed = 0;

        if (keyState[SDL_GetScancodeFromKey(controls["left"])]) {
            x_speed = -SPEED;
        }
        if (keyState[SDL_GetScancodeFromKey(controls["right"])]) {
            x_speed = SPEED;
        }

        if (keyState[SDL_GetScancodeFromKey(controls["jump"])] && !jumping) {
            y_speed = -JUMP_POWER;
            jumping = true;
        }

        attacking = keyState[SDL_GetScancodeFromKey(controls["attack"])];
    }

    void update() {
        y_speed += GRAVITY;

        rect.x += x_speed;
        rect.y += y_speed;

        // Ground Collision
        if (rect.y + rect.h > HEIGHT - 100) { // Assuming ground is at HEIGHT - 100
            rect.y = HEIGHT - 100 - rect.h;
            y_speed = 0;
            jumping = false;
        }

        // Screen Bounds Collision
        if (rect.x < 0) rect.x = 0;
        if (rect.x + rect.w > WIDTH) rect.x = WIDTH - rect.w;
    }

    void hit(int dmg) {
        damage += dmg;
        double knockback = std::min(dmg * KNOCKBACK_MULTIPLIER * ((damage / 10.0) + 1.0), 15.0);
        int direction = (rect.x + rect.w / 2 < WIDTH / 2) ? -1 : 1;
        x_speed += static_cast<int>(knockback * direction);
        y_speed = static_cast<int>(-knockback / 2);
        jumping = true;
    }

    void render(SDL_Renderer* renderer) {
        SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
        SDL_RenderFillRect(renderer, &rect);

        // Optional: Render attacking state (e.g., change color)
        if (attacking) {
            SDL_SetRenderDrawColor(renderer, 255, 0, 255, 255); // Purple when attacking
            SDL_RenderDrawRect(renderer, &rect);
        }
    }
};

int main(int argc, char* args[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        SDL_Log("SDL could not initialize! SDL_Error: %s", SDL_GetError());
        return 1;
    }

    // Create Window
    SDL_Window* window = SDL_CreateWindow("SDL Player",
                                          SDL_WINDOWPOS_CENTERED,
                                          SDL_WINDOWPOS_CENTERED,
                                          WIDTH, HEIGHT,
                                          SDL_WINDOW_SHOWN);
    if (!window) {
        SDL_Log("Window could not be created! SDL_Error: %s", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // Create Renderer
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        SDL_Log("Renderer could not be created! SDL_Error: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    // Define Controls
    std::map<std::string, SDL_Keycode> controls = {
        {"left", SDLK_LEFT},
        {"right", SDLK_RIGHT},
        {"jump", SDLK_SPACE},
        {"attack", SDLK_a}
    };

    // Create Player
    Player player(100, HEIGHT - 160, {255, 0, 0, 255}, controls); // Positioned above the ground

    bool running = true;
    SDL_Event event;

    // Frame Rate Control
    const int FPS = 60;
    const int frameDelay = 1000 / FPS;
    Uint32 frameStart;
    int frameTime;

    while (running) {
        frameStart = SDL_GetTicks();

        // Event Handling
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            }
        }

        // Get Current Keyboard State
        const Uint8* keyState = SDL_GetKeyboardState(NULL);

        // Handle Player Input and Update
        player.handleEvent(keyState);
        player.update();

        // Rendering
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255); // Clear with white
        SDL_RenderClear(renderer);

        // Optional: Render Ground
        SDL_Rect ground = {0, HEIGHT - 100, WIDTH, 100};
        SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255); // Grey ground
        SDL_RenderFillRect(renderer, &ground);

        // Render Player
        player.render(renderer);

        SDL_RenderPresent(renderer);

        // Frame Rate Control
        frameTime = SDL_GetTicks() - frameStart;
        if (frameDelay > frameTime) {
            SDL_Delay(frameDelay - frameTime);
        }
    }

    // Clean Up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
