// chess_game.c

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h> // for abs()
#include <string.h> // for strcmp
#include <stdlib.h> // for exit

// Window dimensions
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 800

// Chessboard dimensions
#define BOARD_SIZE 8
#define SQUARE_SIZE (WINDOW_WIDTH / BOARD_SIZE)

// Enumeration for different piece types
typedef enum {
    EMPTY,
    WP, // White Pawn
    WR, // White Rook
    WN, // White Knight
    WB, // White Bishop
    WQ, // White Queen
    WK, // White King
    BP, // Black Pawn
    BR, // Black Rook
    BN, // Black Knight
    BB, // Black Bishop
    BQ, // Black Queen
    BK  // Black King
} PieceType;

// Structure to represent each square on the board
typedef struct {
    PieceType type;
} Square;

// 8x8 Chessboard
Square board[BOARD_SIZE][BOARD_SIZE];

// Structure to represent the game state
typedef struct {
    bool whiteTurn;      // True if it's White's turn
    bool pieceSelected;  // True if a piece is currently selected
    int selectedRow;     // Row of the selected piece
    int selectedCol;     // Column of the selected piece
} GameState;

// Return true if piece belongs to White
bool isWhitePiece(PieceType piece) {
    return (piece >= WP && piece <= WK);
}

// Return true if piece belongs to Black
bool isBlackPiece(PieceType piece) {
    return (piece >= BP && piece <= BK);
}

// Function to initialize the board with starting positions
void initializeBoard() {
    // Initialize all squares to EMPTY
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            board[row][col].type = EMPTY;
        }
    }

    // Place Black pieces (top rows)
    board[0][0].type = BR; board[0][1].type = BN; board[0][2].type = BB; board[0][3].type = BQ;
    board[0][4].type = BK; board[0][5].type = BB; board[0][6].type = BN; board[0][7].type = BR;
    for (int col = 0; col < BOARD_SIZE; col++) {
        board[1][col].type = BP;
    }

    // Place White pieces (bottom rows)
    board[7][0].type = WR; board[7][1].type = WN; board[7][2].type = WB; board[7][3].type = WQ;
    board[7][4].type = WK; board[7][5].type = WB; board[7][6].type = WN; board[7][7].type = WR;
    for (int col = 0; col < BOARD_SIZE; col++) {
        board[6][col].type = WP;
    }
}

// Function to get the text representation of a piece
const char* getPieceText(PieceType type) {
    switch (type) {
        case WP: return "P";
        case WR: return "R";
        case WN: return "N";
        case WB: return "B";
        case WQ: return "Q";
        case WK: return "K";
        case BP: return "p";
        case BR: return "r";
        case BN: return "n";
        case BB: return "b";
        case BQ: return "q";
        case BK: return "k";
        default: return "";
    }
}

// Check if there is any piece of the same color at destination
bool sameColor(PieceType p1, PieceType p2) {
    if (p1 == EMPTY || p2 == EMPTY) return false;
    return (isWhitePiece(p1) && isWhitePiece(p2)) ||
           (isBlackPiece(p1) && isBlackPiece(p2));
}

// Check if path between (r1, c1) and (r2, c2) is clear (for sliding pieces)
bool pathIsClear(int r1, int c1, int r2, int c2) {
    int rowDiff = r2 - r1;
    int colDiff = c2 - c1;

    // Determine step for row and col
    int stepRow = (rowDiff == 0) ? 0 : (rowDiff > 0 ? 1 : -1);
    int stepCol = (colDiff == 0) ? 0 : (colDiff > 0 ? 1 : -1);

    // Number of steps to get from (r1, c1) to (r2, c2)
    int steps = (abs(rowDiff) > abs(colDiff)) ? abs(rowDiff) : abs(colDiff);

    // Check each square in path (excluding the starting square)
    for (int i = 1; i < steps; i++) {
        int rr = r1 + stepRow * i;
        int cc = c1 + stepCol * i;
        if (board[rr][cc].type != EMPTY) {
            return false; // blocked
        }
    }
    return true;
}

// Basic piece-specific move validation (no check, no castling, no en passant, no promotion)
bool isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
    PieceType piece = board[fromRow][fromCol].type;
    PieceType destPiece = board[toRow][toCol].type;

    // If destination has a same-color piece, invalid
    if (sameColor(piece, destPiece)) {
        return false;
    }

    int rowDiff = toRow - fromRow;
    int colDiff = toCol - fromCol;
    int absRowDiff = abs(rowDiff);
    int absColDiff = abs(colDiff);

    switch (piece) {
        // White Pawn
        case WP: {
            // Move direction is up the board (row decreases)
            // Basic 1-square move forward
            if (destPiece == EMPTY && colDiff == 0) {
                // 2-step move from row 6
                if (fromRow == 6 && rowDiff == -2) {
                    // Must not be blocked
                    if (board[fromRow - 1][fromCol].type == EMPTY && pathIsClear(fromRow, fromCol, toRow, toCol)) {
                        return true;
                    }
                }
                // Normal 1-step forward
                if (rowDiff == -1) {
                    return true;
                }
            }
            // Capture: diagonal
            if (destPiece != EMPTY && absColDiff == 1 && rowDiff == -1) {
                // capturing black piece
                if (isBlackPiece(destPiece)) {
                    return true;
                }
            }
            return false;
        }
        // Black Pawn
        case BP: {
            // Move direction is down the board (row increases)
            if (destPiece == EMPTY && colDiff == 0) {
                // 2-step move from row 1
                if (fromRow == 1 && rowDiff == 2) {
                    // Must not be blocked
                    if (board[fromRow + 1][fromCol].type == EMPTY && pathIsClear(fromRow, fromCol, toRow, toCol)) {
                        return true;
                    }
                }
                // Normal 1-step forward
                if (rowDiff == 1) {
                    return true;
                }
            }
            // Capture: diagonal
            if (destPiece != EMPTY && absColDiff == 1 && rowDiff == 1) {
                // capturing white piece
                if (isWhitePiece(destPiece)) {
                    return true;
                }
            }
            return false;
        }
        // Knight
        case WN:
        case BN: {
            // Knight moves in L-shape
            if ((absRowDiff == 2 && absColDiff == 1) || (absRowDiff == 1 && absColDiff == 2)) {
                return true;
            }
            return false;
        }
        // Bishop
        case WB:
        case BB: {
            // Must move diagonally
            if (absRowDiff == absColDiff) {
                // path must be clear
                return pathIsClear(fromRow, fromCol, toRow, toCol);
            }
            return false;
        }
        // Rook
        case WR:
        case BR: {
            // Must move in straight line
            if (rowDiff == 0 || colDiff == 0) {
                // path must be clear
                return pathIsClear(fromRow, fromCol, toRow, toCol);
            }
            return false;
        }
        // Queen
        case WQ:
        case BQ: {
            // Combine rook & bishop logic
            if (rowDiff == 0 || colDiff == 0 || (absRowDiff == absColDiff)) {
                // path must be clear
                return pathIsClear(fromRow, fromCol, toRow, toCol);
            }
            return false;
        }
        // King
        case WK:
        case BK: {
            // King moves 1 square in any direction
            if (absRowDiff <= 1 && absColDiff <= 1) {
                return true;
            }
            return false;
        }
        default:
            return false;
    }
}

int main(int argc, char* argv[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    // Initialize SDL_ttf
    if (TTF_Init() == -1) {
        printf("TTF_Init Error: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }

    // Create SDL Window
    SDL_Window* win = SDL_CreateWindow("Chess with Basic Engine",
                                       SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED,
                                       WINDOW_WIDTH,
                                       WINDOW_HEIGHT,
                                       SDL_WINDOW_SHOWN);
    if (!win) {
        printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Create Renderer
    SDL_Renderer* ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!ren) {
        SDL_DestroyWindow(win);
        printf("SDL_CreateRenderer Error: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Load Font (Attempt multiple common fonts if Arial.ttf is not found)
    TTF_Font* font = NULL;
    const char* fontPaths[] = {
        "Arial.ttf", // Current directory
        "/Library/Fonts/Arial.ttf", // macOS standard path
        "/System/Library/Fonts/Supplemental/Arial.ttf", // macOS supplemental fonts
        "/Library/Fonts/Verdana.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf", // Linux
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf" // Linux
    };
    int numFonts = sizeof(fontPaths) / sizeof(fontPaths[0]);
    for (int i = 0; i < numFonts; i++) {
        font = TTF_OpenFont(fontPaths[i], SQUARE_SIZE / 2);
        if (font) {
            printf("Loaded font: %s\n", fontPaths[i]);
            break;
        }
    }
    if (!font) {
        printf("TTF_OpenFont Error: Couldn't open any of the specified fonts.\n");
        SDL_DestroyRenderer(ren);
        SDL_DestroyWindow(win);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    // Initialize the board
    initializeBoard();

    // Initialize game state
    GameState gameState = {
        .whiteTurn = true,
        .pieceSelected = false,
        .selectedRow = -1,
        .selectedCol = -1
    };

    bool quit = false;
    SDL_Event e;

    // Main loop
    while (!quit) {
        // Handle events
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
            else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
                int x, y;
                SDL_GetMouseState(&x, &y);
                int clickedCol = x / SQUARE_SIZE;
                int clickedRow = y / SQUARE_SIZE;

                if (clickedRow >= 0 && clickedRow < BOARD_SIZE &&
                    clickedCol >= 0 && clickedCol < BOARD_SIZE)
                {
                    PieceType clickedPiece = board[clickedRow][clickedCol].type;

                    // If a piece is already selected
                    if (gameState.pieceSelected) {
                        int fromRow = gameState.selectedRow;
                        int fromCol = gameState.selectedCol;
                        PieceType selectedPiece = board[fromRow][fromCol].type;

                        // Check if the move is valid for the piece
                        if ((gameState.whiteTurn && isWhitePiece(selectedPiece)) ||
                            (!gameState.whiteTurn && isBlackPiece(selectedPiece)))
                        {
                            if (isValidMove(fromRow, fromCol, clickedRow, clickedCol)) {
                                // Move the piece
                                board[clickedRow][clickedCol].type = selectedPiece;
                                board[fromRow][fromCol].type = EMPTY;

                                // Switch turn
                                gameState.whiteTurn = !gameState.whiteTurn;
                            }
                        }
                        // Deselect
                        gameState.pieceSelected = false;
                        gameState.selectedRow = -1;
                        gameState.selectedCol = -1;
                    }
                    else {
                        // Select a piece if it’s the player's turn & belongs to that player
                        if (clickedPiece != EMPTY) {
                            bool belongsToWhite = isWhitePiece(clickedPiece);
                            if ((gameState.whiteTurn && belongsToWhite) ||
                                (!gameState.whiteTurn && !belongsToWhite))
                            {
                                gameState.pieceSelected = true;
                                gameState.selectedRow = clickedRow;
                                gameState.selectedCol = clickedCol;
                            }
                        }
                    }
                }
            }
            else if (e.type == SDL_KEYDOWN) {
                // ESC to quit
                if (e.key.keysym.sym == SDLK_ESCAPE) {
                    quit = true;
                }
                // R to reset
                else if (e.key.keysym.sym == SDLK_r) {
                    initializeBoard();
                    gameState.whiteTurn = true;
                    gameState.pieceSelected = false;
                    gameState.selectedRow = -1;
                    gameState.selectedCol = -1;
                }
            }
        }

        // Clear screen (light gray)
        SDL_SetRenderDrawColor(ren, 200, 200, 200, 255);
        SDL_RenderClear(ren);

        // Draw chessboard squares
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if ((row + col) % 2 == 0) {
                    SDL_SetRenderDrawColor(ren, 255, 255, 255, 255); // White
                } else {
                    SDL_SetRenderDrawColor(ren, 100, 100, 100, 255); // Gray
                }

                SDL_Rect square = {
                    .x = col * SQUARE_SIZE,
                    .y = row * SQUARE_SIZE,
                    .w = SQUARE_SIZE,
                    .h = SQUARE_SIZE
                };
                SDL_RenderFillRect(ren, &square);
            }
        }

        // Highlight selected square
        if (gameState.pieceSelected) {
            SDL_SetRenderDrawColor(ren, 0, 255, 0, 100); // Semi-transparent green
            SDL_Rect highlight = {
                .x = gameState.selectedCol * SQUARE_SIZE,
                .y = gameState.selectedRow * SQUARE_SIZE,
                .w = SQUARE_SIZE,
                .h = SQUARE_SIZE
            };
            SDL_RenderFillRect(ren, &highlight);
        }

        // Draw pieces
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                PieceType piece = board[row][col].type;
                if (piece != EMPTY) {
                    const char* text = getPieceText(piece);

                    // White or Black color
                    SDL_Color color = isWhitePiece(piece)
                                      ? (SDL_Color){255, 255, 255, 255}
                                      : (SDL_Color){0, 0, 0, 255};

                    SDL_Surface* surface = TTF_RenderText_Solid(font, text, color);
                    if (!surface) {
                        printf("TTF_RenderText_Solid Error: %s\n", TTF_GetError());
                        continue;
                    }

                    SDL_Texture* texture = SDL_CreateTextureFromSurface(ren, surface);
                    if (!texture) {
                        printf("SDL_CreateTextureFromSurface Error: %s\n", SDL_GetError());
                        SDL_FreeSurface(surface);
                        continue;
                    }

                    // Center the piece on its square
                    SDL_Rect dst;
                    dst.w = SQUARE_SIZE / 2;
                    dst.h = SQUARE_SIZE / 2;
                    dst.x = col * SQUARE_SIZE + (SQUARE_SIZE - dst.w) / 2;
                    dst.y = row * SQUARE_SIZE + (SQUARE_SIZE - dst.h) / 2;

                    SDL_RenderCopy(ren, texture, NULL, &dst);

                    // Cleanup
                    SDL_DestroyTexture(texture);
                    SDL_FreeSurface(surface);
                }
            }
        }

        // Present the frame
        SDL_RenderPresent(ren);
    }

    // Cleanup
    TTF_CloseFont(font);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
