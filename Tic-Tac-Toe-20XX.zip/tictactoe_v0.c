// Tic Tac Toe Game

#include <stdio.h>

// Function to initialize the game board
void initialize(char board[3][3]) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board[i][j] = ' ';
        }
    }
}

// Function to print the game board
void printBoard(char board[3][3]) {
    printf("\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf(" %c ", board[i][j]);
            if (j != 2) {
                printf("|");
            }
        }
        printf("\n");
        if (i != 2) {
            printf("---+---+---\n");
        }
    }
    printf("\n");
}

// Function to check if the game is over
int isGameOver(char board[3][3]) {
    // Check rows
    for (int i = 0; i < 3; i++) {
        if (board[i][0] != ' ' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
            return 1;
        }
    }

    // Check columns
    for (int j = 0; j < 3; j++) {
        if (board[0][j] != ' ' && board[0][j] == board[1][j] && board[1][j] == board[2][j]) {
            return 1;
        }
    }

    // Check diagonals
    if (board[0][0] != ' ' && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
        return 1;
    }
    if (board[0][2] != ' ' && board[0][2] == board[1][1] && board[1][1] == board[2][0]) {
        return 1;
    }

    // Check if the board is full
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ') {
                return 0;
            }
        }
    }

    // If none of the above conditions are met, the game is a draw
    return -1;
}

// Function to play the game
void playGame() {
    char board[3][3];
    int currentPlayer = 1;
    int row, col;
    int gameOver = 0;

    // Initialize the game board
    initialize(board);

    // Game loop
    while (!gameOver) {
        // Print the game board
        printBoard(board);

        // Get the current player's move
        printf("Player %d's turn. Enter row and column (0-2): ", currentPlayer);
        scanf("%d %d", &row, &col);

        // Validate the move
        if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            printf("Invalid move! Try again.\n");
            continue;
        }

        // Make the move
        if (currentPlayer == 1) {
            board[row][col] = 'X';
            currentPlayer = 2;
        } else {
            board[row][col] = 'O';
            currentPlayer = 1;
        }

        // Check if the game is over
        gameOver = isGameOver(board);
    }

    // Print the final game board
    printBoard(board);

    // Print the game result
    if (gameOver == 1) {
        printf("Player %d wins!\n", currentPlayer);
    } else {
        printf("It's a draw!\n");
    }
}

int main() {
    // Play the game
    playGame();

    return 0;
}