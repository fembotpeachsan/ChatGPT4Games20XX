import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("Breakout - @FlamesLLC")

# Game Boy green filter colors
GREEN1 = (15, 56, 15)
GREEN2 = (48, 98, 48)
GREEN3 = (139, 172, 15)
GREEN4 = (155, 188, 15)

# Game objects
paddle = pygame.Rect(270, 350, 60, 10)
ball = pygame.Rect(295, 330, 10, 10)
bricks = [pygame.Rect(x * 55 + 25, y * 15 + 30, 50, 10) for x in range(10) for y in range(3)]

ball_speed = [2, -2]

# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Paddle movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and paddle.left > 0:
        paddle.left -= 5
    if keys[pygame.K_RIGHT] and paddle.right < 600:
        paddle.right += 5

    # Ball movement
    ball.x += ball_speed[0]
    ball.y += ball_speed[1]

    # Ball collision with the walls
    if ball.left <= 0 or ball.right >= 600:
        ball_speed[0] = -ball_speed[0]
    if ball.top <= 0:
        ball_speed[1] = -ball_speed[1]

    # Ball collision with the paddle
    if ball.colliderect(paddle):
        ball_speed[1] = -ball_speed[1]

    # Ball collision with the bricks
    brick_collision_index = ball.collidelist(bricks)
    if brick_collision_index != -1:
        ball_speed[1] = -ball_speed[1]
        bricks.pop(brick_collision_index)

    # Ball out of bounds
    if ball.top > 400:
        ball.x, ball.y = 295, 330
        ball_speed[1] = -ball_speed[1]

    # Draw everything
    screen.fill(GREEN1)
    pygame.draw.rect(screen, GREEN4, paddle)
    pygame.draw.ellipse(screen, GREEN4, ball)
    for brick in bricks:
        pygame.draw.rect(screen, GREEN3, brick)

    pygame.display.flip()
    pygame.time.Clock().tick(60)
