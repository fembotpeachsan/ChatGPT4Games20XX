import pygame
import sys

# Initialize Pygame
pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PADDLE_WIDTH = 10
PADDLE_HEIGHT = 100
BALL_RADIUS = 10
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Set up the display
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Pong Game')

# Set up the colors

# Set up the ball
ball_pos = [SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2]
ball_vel = [2, 2]

# Set up the paddles
left_paddle_pos = [0, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2]
right_paddle_pos = [SCREEN_WIDTH - PADDLE_WIDTH, SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2]
paddle_vel = 4

# Set up the score
left_score = 0
right_score = 0
font = pygame.font.Font(None, 36)

# Set up the block at the edge of the window
block_pos = [SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2]
block_size = [10, SCREEN_HEIGHT]

# Initialize the clock for FPS control
clock = pygame.time.Clock()

# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    keys = pygame.key.get_pressed()

    if keys[pygame.K_w] and left_paddle_pos[1] > 0:
        left_paddle_pos[1] -= paddle_vel
    if keys[pygame.K_s] and left_paddle_pos[1] < SCREEN_HEIGHT - PADDLE_HEIGHT:
        left_paddle_pos[1] += paddle_vel
    if keys[pygame.K_UP] and right_paddle_pos[1] > 0:
        right_paddle_pos[1] -= paddle_vel
    if keys[pygame.K_DOWN] and right_paddle_pos[1] < SCREEN_HEIGHT - PADDLE_HEIGHT:
        right_paddle_pos[1] += paddle_vel

    # Update ball position
    ball_pos[0] += ball_vel[0]
    ball_pos[1] += ball_vel[1]

    # Ball collision with top and bottom
    if ball_pos[1] <= 0 or ball_pos[1] >= SCREEN_HEIGHT:
        ball_vel[1] = -ball_vel[1]

    # Ball collision with paddles
    if (left_paddle_pos[1] < ball_pos[1] < left_paddle_pos[1] + PADDLE_HEIGHT and ball_pos[0] <= PADDLE_WIDTH):
        ball_vel[0] = -ball_vel[0]
        left_score += 1
    elif (right_paddle_pos[1] < ball_pos[1] < right_paddle_pos[1] + PADDLE_HEIGHT and ball_pos[0] >= SCREEN_WIDTH - PADDLE_WIDTH):
        ball_vel[0] = -ball_vel[0]
        right_score += 1

    # Ball collision with block
    if ball_pos[0] <= 0 or ball_pos[0] >= SCREEN_WIDTH:
        ball_vel[0] = -ball_vel[0]

    # Draw everything
    window.fill(BLACK)
    pygame.draw.rect(window, WHITE, pygame.Rect(left_paddle_pos[0], left_paddle_pos[1], PADDLE_WIDTH, PADDLE_HEIGHT))
    pygame.draw.rect(window, WHITE, pygame.Rect(right_paddle_pos[0], right_paddle_pos[1], PADDLE_WIDTH, PADDLE_HEIGHT))
    pygame.draw.circle(window, WHITE, ball_pos, BALL_RADIUS)
    pygame.draw.rect(window, WHITE, pygame.Rect(block_pos[0] - block_size[0] // 2, block_pos[1] - block_size[1] // 2, block_size[0], block_size[1]))

    # Draw the score
    left_score_text = font.render(str(left_score), True, WHITE)
    right_score_text = font.render(str(right_score), True, WHITE)
    window.blit(left_score_text, (SCREEN_WIDTH // 4 - left_score_text.get_width() // 2, 10))
    window.blit(right_score_text, (SCREEN_WIDTH // 4 * 3 - right_score_text.get_width() // 2, 10))

    pygame.display.flip()
    clock.tick(60)