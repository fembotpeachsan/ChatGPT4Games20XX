import pygame
import sys
from pygame.locals import *

pygame.init()

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PADDLE_WIDTH = 10
PADDLE_HEIGHT = 60
BALL_SIZE = 8
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Initialize screen and clock
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Pong 20XX')
clock = pygame.time.Clock()

# Paddle and ball rects
paddle_a = pygame.Rect(10, (SCREEN_HEIGHT - PADDLE_HEIGHT) / 2, PADDLE_WIDTH, PADDLE_HEIGHT)
paddle_b = pygame.Rect(SCREEN_WIDTH - 20, (SCREEN_HEIGHT - PADDLE_HEIGHT) / 2, PADDLE_WIDTH, PADDLE_HEIGHT)
ball = pygame.Rect((SCREEN_WIDTH - BALL_SIZE) / 2, (SCREEN_HEIGHT - BALL_SIZE) / 2, BALL_SIZE, BALL_SIZE)

# Ball movement
ball_speed_x = -1
ball_speed_y = -1

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

    # Paddle movement
    keys = pygame.key.get_pressed()
    if keys[K_w] and paddle_a.top > 0:
        paddle_a.y -= 5
    if keys[K_s] and paddle_a.bottom < SCREEN_HEIGHT:
        paddle_a.y += 5
    if keys[K_UP] and paddle_b.top > 0:
        paddle_b.y -= 5
    if keys[K_DOWN] and paddle_b.bottom < SCREEN_HEIGHT:
        paddle_b.y += 5

    # Ball movement
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    # Ball collision with walls
    if ball.top <= 0 or ball.bottom >= SCREEN_HEIGHT:
        ball_speed_y = -ball_speed_y

    # Ball collision with paddles
    if ball.colliderect(paddle_a) or ball.colliderect(paddle_b):
        ball_speed_x = -ball_speed_x

    # Ball out of bounds (reset ball position)
    if ball.left <= 0 or ball.right >= SCREEN_WIDTH:
        ball.x = (SCREEN_WIDTH - BALL_SIZE) / 2
        ball.y = (SCREEN_HEIGHT - BALL_SIZE) / 2

    # Draw
    screen.fill(BLACK)
    pygame.draw.rect(screen, WHITE, paddle_a)
    pygame.draw.rect(screen, WHITE, paddle_b)
    pygame.draw.ellipse(screen, WHITE, ball)
    pygame.draw.aaline(screen, WHITE, (SCREEN_WIDTH / 2, 0), (SCREEN_WIDTH / 2, SCREEN_HEIGHT))

    pygame.display.flip()
    clock.tick(FPS)
