#include <SDL2/SDL.h>
#include <stdbool.h>

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;
const int PADDLE_WIDTH = 15;
const int PADDLE_HEIGHT = 100;
const int BALL_SIZE = 15;
const int PADDLE_SPEED = 6; // Reduced speed for smoother paddle movement
const int BALL_SPEED_X = 5;
const int BALL_SPEED_Y = 5;
const int FPS = 60; // Increased FPS for smoother gameplay
const int FRAME_DELAY = 1000 / FPS; // Adjusted frame delay for 60 FPS

int scorePlayer1 = 0;
int scorePlayer2 = 0;

typedef struct {
    int x, y;
    int width, height;
    int dy;
} Paddle;

typedef struct {
    int x, y;
    int dx, dy;
    int size;
} Ball;

void initPaddle(Paddle *p, int x, int y) {
    p->x = x;
    p->y = y;
    p->width = PADDLE_WIDTH;
    p->height = PADDLE_HEIGHT;
    p->dy = 0;
}

void initBall(Ball *b, int x, int y) {
    b->x = x;
    b->y = y;
    b->dx = BALL_SPEED_X;
    b->dy = BALL_SPEED_Y;
    b->size = BALL_SIZE;
}

void resetBall(Ball *b) {
    b->x = WINDOW_WIDTH / 2 - b->size / 2;
    b->y = WINDOW_HEIGHT / 2 - b->size / 2;
    b->dx = -b->dx; // Change direction to start towards the player who scored
}

void movePaddle(Paddle *p) {
    p->y += p->dy;
    if (p->y < 0) p->y = 0;
    else if (p->y + PADDLE_HEIGHT > WINDOW_HEIGHT) p->y = WINDOW_HEIGHT - PADDLE_HEIGHT;
}

void moveBall(Ball *b, Paddle *leftPaddle, Paddle *rightPaddle) {
    b->x += b->dx;
    b->y += b->dy;

    if (b->y < 0 || b->y + b->size > WINDOW_HEIGHT) {
        b->dy = -b->dy;
    }

    // Ball leaves the left side
    if (b->x < 0) {
        scorePlayer2++;
        resetBall(b);
    }

    // Ball leaves the right side
    if (b->x > WINDOW_WIDTH) {
        scorePlayer1++;
        resetBall(b);
    }
}

void collisionDetection(Ball *b, Paddle *p1, Paddle *p2) {
    if (b->x <= p1->x + p1->width && b->x > p1->x && b->y > p1->y && b->y < p1->y + p1->height) {
        b->dx = -b->dx;
    } else if (b->x + b->size >= p2->x && b->x < p2->x + p2->width && b->y > p2->y && b->y < p2->y + p2->height) {
        b->dx = -b->dx;
    }
}

void aiMove(Paddle *aiPaddle, Ball *ball) {
    if (ball->y + ball->size < aiPaddle->y + aiPaddle->height / 2) {
        aiPaddle->dy = -PADDLE_SPEED;
    } else if (ball->y > aiPaddle->y + aiPaddle->height / 2) {
        aiPaddle->dy = PADDLE_SPEED;
    } else {
        aiPaddle->dy = 0;
    }
}

void drawScore(SDL_Renderer *renderer, int player1Score, int player2Score) {
    // Simple ASCII-like score rendering using rectangles
    char scoreText[16];
    snprintf(scoreText, sizeof(scoreText), "P1: %d  P2: %d", player1Score, player2Score);
    int startX = 350;
    int startY = 20;
    for (int i = 0; scoreText[i] != '\0'; i++) {
        if (scoreText[i] >= '0' && scoreText[i] <= '9') {
            // Example: Render each digit as a block
            SDL_Rect rect = {startX + i * 20, startY, 18, 28};
            SDL_RenderFillRect(renderer, &rect);
        }
    }
}

int main(int argc, char *argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window *window = SDL_CreateWindow("Pong", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    Paddle playerPaddle, aiPaddle;
    Ball ball;
    initPaddle(&playerPaddle, 30, (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2);
    initPaddle(&aiPaddle, WINDOW_WIDTH - 30 - PADDLE_WIDTH, (WINDOW_HEIGHT - PADDLE_HEIGHT) / 2);
    initBall(&ball, WINDOW_WIDTH / 2 - BALL_SIZE / 2, WINDOW_HEIGHT / 2 - BALL_SIZE / 2);

    bool running = true;
    SDL_Event event;
    uint32_t frameStart;
    int frameTime;

    while (running) {
        frameStart = SDL_GetTicks();

        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            }
            if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.sym) {
                    case SDLK_w:
                        playerPaddle.dy = -PADDLE_SPEED;
                        break;
                    case SDLK_s:
                        playerPaddle.dy = PADDLE_SPEED;
                        break;
                }
            }
            if (event.type == SDL_KEYUP) {
                if (event.key.keysym.sym == SDLK_w || event.key.keysym.sym == SDLK_s) {
                    playerPaddle.dy = 0;
                }
            }
        }

        aiMove(&aiPaddle, &ball);
        movePaddle(&playerPaddle);
        movePaddle(&aiPaddle);
        moveBall(&ball, &playerPaddle, &aiPaddle);
        collisionDetection(&ball, &playerPaddle, &aiPaddle);

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_Rect playerRect = { playerPaddle.x, playerPaddle.y, PADDLE_WIDTH, PADDLE_HEIGHT };
        SDL_Rect aiRect = { aiPaddle.x, aiPaddle.y, PADDLE_WIDTH, PADDLE_HEIGHT };
        SDL_Rect ballRect = { ball.x, ball.y, BALL_SIZE, BALL_SIZE };
        SDL_RenderFillRect(renderer, &playerRect);
        SDL_RenderFillRect(renderer, &aiRect);
        SDL_RenderFillRect(renderer, &ballRect);

        SDL_RenderPresent(renderer);

        frameTime = SDL_GetTicks() - frameStart;
        if (FRAME_DELAY > frameTime) {
            SDL_Delay(FRAME_DELAY - frameTime);
        }
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}