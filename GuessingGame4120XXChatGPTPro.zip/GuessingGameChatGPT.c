#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int secret_number, guess, attempts = 0;

    // Initialize random number generator with current time as seed
    srand(time(0));
    secret_number = rand() % 100 + 1; // Generate random number between 1 and 100

    printf("I'm thinking of a number between 1 and 100.\n");

    do {
        printf("Enter your guess: ");
        scanf("%d", &guess);
        attempts++;

        if (guess < secret_number) {
            printf("Too low! Try again.\n");
        } else if (guess > secret_number) {
            printf("Too high! Try again.\n");
        } else {
            printf("Congratulations! You found the secret number in %d attempts.\n", attempts);
        }
    } while (guess != secret_number);

    return 0;
}