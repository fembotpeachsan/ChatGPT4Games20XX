import random

def main():
    number = random.randint(1, 100)
    attempts = 0
    
    print("Welcome to the Guessing Game!")
    
    while True:
        try:
            user_guess = int(input("Guess a number between 1 and 100: "))
            
            if user_guess < 1 or user_guess > 100:
                raise ValueError()
                
        except ValueError as e:
            print("Please enter an integer between (inclusive) of range provided.")
        
        else: 
            # Check if guessed correctly.
            attempts +=1
            
            if user_guess == number :
                print(f"Congratulations! You've guessed it right after {attempts} tries")
                break
                
            elif user_guess < number:
                print("Your guess is too low, try again.")
                  

if __name__=="__main__":
      main()
