import pygame
import random
import time
pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Lucid Dream")
# Load the day and night filters
day_filter = pygame.Surface((800, 600), pygame.SRCALPHA)
night_filter = pygame.Surface((800, 600), pygame.SRCALPHA)

# Define the dreamlike colors
day_filter.fill((50, 100, 200, 128))
night_filter.fill((0, 0, 100, 128))
class SleepEngine:
    def __init__(self, day_duration, night_duration):
        self.day_duration = day_duration
        self.night_duration = night_duration
        self.is_day = True
        self.time_passed = 0

    def update(self, dt):
        self.time_passed += dt
        if self.is_day and self.time_passed >= self.day_duration:
            self.is_day = False
            self.time_passed = 0
        elif not self.is_day and self.time_passed >= self.night_duration:
            self.is_day = True
            self.time_passed = 0

    def get_current_filter(self):
        return day_filter if self.is_day else night_filter
